export class BusDetails {
  busNo: number;
  sourceBusstop: string;
  destinationBusstop: string;
  availableSeats: number;
  departureDate: string;
  arrivalDate: string;
  arrivalTime: string;
  departureTime: string;
  busVendor: string;
  price: number;
}
