import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AdminService } from "../services/admin.service"; // Import necessary services

@Component({
  selector: "app-schedule-user",
  templateUrl: "./schedule-user.component.html",
  styleUrls: ["./schedule-user.component.css"],
})
export class ScheduleUserComponent implements OnInit {
  bus = null;
  adminId = null;

  constructor(private adminService: AdminService, private router: Router) {}

  ngOnInit() {
    console.log("Retrieving data");
    this.adminId = localStorage.getItem("adminId");
    if (this.adminId == null) {
      this.router.navigate(["/error", "login to continue"]);
    } else {
      this.adminService.viewAllBus().subscribe(
        (data) => {
          this.bus = data;
        },
        (error) => {
          this.router.navigate(["/error", "some error occurred"]);
        }
      );
    }
  }

  bookNow(busNumber: string) {
    this.router.navigate(["/addPassengers", busNumber]); // Navigate to Add Passengers component
  }
}
