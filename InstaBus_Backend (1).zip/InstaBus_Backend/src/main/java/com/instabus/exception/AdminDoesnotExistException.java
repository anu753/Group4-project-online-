package com.instabus.exception;

public class AdminDoesnotExistException extends RuntimeException {

	public AdminDoesnotExistException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AdminDoesnotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
